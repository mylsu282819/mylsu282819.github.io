/**
 * Profiler for the Natural Log Class
 * @author Kha Viet Le
 * @since 01/26/19
 * @see lntimes.xls
 * <pre>
 * CSC 3102 Programming Project #0
 * Date: 01/26/19
 * </pre>
 */
package naturallogprofiler;

import java.util.Scanner;
import java.util.Random;

public class NaturalLogProfiler
{

    public static void main(String[] args)
    {
        Scanner cin = new Scanner(System.in);
        Random generator = new Random(System.currentTimeMillis());

        System.out.print("Enter a number to approximate its natural log -> ");
        double input1 = cin.nextDouble();
        System.out.printf("Naive Algorithm: ln(%.1f) ~ %f%n", input1, NaturalLogger.naiveLn(input1));
        System.out.printf("Fast Algorithm: ln(%.1f) ~ %f%n%n", input1, NaturalLogger.fastLn(input1));
        
        System.out.println("For a random 3-digit positive integer:");
        int input2 = generator.nextInt(900)+100;
        System.out.printf("Naive Algorithm: ln(%d) ~ %f%n", input2, NaturalLogger.naiveLn(input2));
        System.out.printf("Fast Algorithm: ln(%d) ~ %f%n%n", input2, NaturalLogger.fastLn(input2));
        
        System.out.print("Enter x to generate approximations for ln(x) -> ");
        double input3 = cin.nextDouble();
        System.out.printf("%nx = %f%n", input3);
        System.out.printf("=================================================%n#Terms      Fast ln(x) (ns)      Naive ln(x) (ns)%n-------------------------------------------------%n");
        for (int i = 1000; i < 10001; i+=1000)
        {
            long start = System.nanoTime();
            NaturalLogger.fastLn(input3, i);
            long fastln_elapsed = System.nanoTime() - start;
            
            start = System.nanoTime();
            NaturalLogger.naiveLn(input3, i);
            long naiveln_elapsed = System.nanoTime() - start;
            
            System.out.printf("%5d%22d%21d%n", i, fastln_elapsed, naiveln_elapsed);
        }
        System.out.println("=================================================");


        
        
    }
    
}
