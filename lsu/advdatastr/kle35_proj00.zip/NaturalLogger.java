package naturallogprofiler;

/** 
 * Implementation for the fast and naive natural log series approximation 
 * algorithms that use the series:
 * 2*Sigma[i=1:n, 1/(2i-1)*[(x-1)/(x+1)]^(2i-1)]
 * @author Kha Viet Le
 * <pre>
 * Date: 01/26/19
 * CSC 3102 Programming Project # 0
 *
 * DO NOT REMOVE THIS NOTICE (GNU GPL V2):
 * Contact Information: duncan@csc.lsu.edu
 * Copyright (c) 2020 William E. Duncan
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 * </pre>
 */
public class NaturalLogger
{
    /**
     * Computes a power with an integer exponent
     * @param b the base of the power
     * @param n an integer representing the exponent of the power
     * @return the power equivalent to the specified base to the specified
     * exponent
     * @throws IllegalArgumentException when b == 0 and n <= 0
     */
    private static double iPow(double b, int n) throws IllegalArgumentException
    {
        if (b == 0 && n <= 0)
        {
            throw new IllegalArgumentException("Invalid argument");
        }
        if (b == 0)
        {
            return 0;
        }
        else if (n == 0)
        {
            return 1;
        }
        else if (b == 1)
        {
            return 1;
        }
        else if (n == 1)
        {
            return b;
        }
        else if (n == -1)
        {
            return 1/b;
        }
        else if (b == -1)
        {
            return n % 2 == 0 ? 1 : -1;
        }
        else
        {
            double product = b;
            int bound = n < 0 ? -1*n : n;          
            for (int i = 1; i < bound; i++)
            {
                product *= b;
            }
            return n > 0 ? product : 1/product;
        }
            
    }

    /**
     * Gives an approximation of the natural log function by naively computing
     * the series 2*Sigma[i=1:50000, 1/(2i-1)*[(x-1)/(x+1)]^(2i-1)]
     * @param x a number whose natural log is to be approximated
     * @return the series approximation of ln(x) using the first 50000 terms
     * @throws IllegalArgumentException when x <= 0
     */
    public static double naiveLn(double x) throws IllegalArgumentException
    {
        return naiveLn(x, 50000);		
    }
    
    /**
     * Gives an approximation of the natural log function by naively computing
     * the series 2*Sigma[i=1:n,1/(2i-1) *[(x-1)/(x+1)]^(2i-1)]
     * @param x a number whose natural log is to be approximated
     * @param n the number of terms in the series
     * @return the series approximation value for ln(x) using the first n terms
     * @throws IllegalArgumentException when x <= 0 or n <= 0
     * <pre>
     * Note: The series should be generated without the use of a nested loop
     * or any standard math library functions; To determine powers use the 
     * user-defined iPow function in this class. Each term of the series is 
     * independently determined using the function that serves as the summand 
     * of the series.
     * </pre>
     */    
    public static double naiveLn(double x, int n) throws IllegalArgumentException
    {
        if (x <= 0 || n <= 0)
        {
            throw new IllegalArgumentException("Invalid argument");
        }
        double result = 0, alpha = (x-1)/(x+1);
        for (int i = 1; i < n*2; i+=2)
        {
            result += iPow(alpha, i)/i;
        }
        return 2*result;
    }
    
    /**
     * Gives an approximation of the natural log function using the fast
     * approximation algorithm that computes the series 
     * 2*Sigma[i=1:50000, 1/(2i-1) *[(x-1)/(x+1)]^(2i-1)]
     * @param x a number whose natural log is to be approximated
     * @return the series approximation of ln(x) using the first 50000 terms
     * @throws IllegalArgumentException when x <= 0
     */    
    public static double fastLn(double x) throws IllegalArgumentException
    {
        return fastLn(x, 50000);
    }
    
    /**
     * Gives an approximation of the natural log function by using the fast algorithm
     * to compute the series 2*Sigma[i=1:n,(1/(2i-1) *[(x-1)/(x+1)]^(2i-1)]]
     * @param x a number whose natural log is to be approximated
     * @param n the number of terms in the series
     * @return the series approximation value for ln(x) using the first n terms
     * @throws IllegalArgumentException when x <= 0 or n <= 0
     * <pre>
     * Note: Except for the first term of the series, each term is generated from its
     * predecessor and without the use or any standard math library functions; 
     * Neither the standard math library functions or the user-defined iPow function
     * should be invoked in this function. This function should not use a nested loop
     * to compute the powers. Each successive power must be generated from the preceding
     * power.
     * </pre>
     */        
    public static double fastLn(double x, int n) throws IllegalArgumentException
    {
        if (x <= 0 || n <= 0)
        {
            throw new IllegalArgumentException("Invalid argument");
        }
        double alpha = (x-1)/(x+1), predecessor = alpha, alphaSqr = alpha * alpha, result = alpha;
        for (int i = 1; i < n*2-2; i+=2)
        {
            predecessor *= alphaSqr * i / (i+2);
            result += predecessor;
        }
        return 2*result;
    }    
}