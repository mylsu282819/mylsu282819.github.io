package pqparser;

import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;
import java.util.Scanner;

/**
 * A simple parser for the following simple instructions on a binary heap 
 * implementation and the heap sort algorithm using various comparators 
 * @see Heap.H
 * @author Duncan, Kha Le
 *  * <pre>
 * COMMANDS [h denotes the heap]
 * command: inserted item
 * executes  -> h.insert(item) and displays "Inserted: item"
 * command: delete
 * displays "Deleted: h.remove()"
 * command: peek
 * displays "Top: h.peek()", where h.peek() returns the top-most item
 * command: stats
 * diplays stats: size = h.size(), height = height(h), diameter = diameter(h)
 * 
 * Date: 02-16-20
 * course: csc 3102
 * programming project 1
 * Instructor: Dr. Duncan
 * </pre>

 */
public class PQParser
{

    /**
     * Determines the height of the specified heap
     * @param <E> the element type of the heap
     * @param h a binary heap of the specified element type
     * @return the height of the heap
     */
    public static <E extends Comparable<E>> int height(Heap<E> h)
    {
        if (h.size() == 0)
            return -1;
        return (int) Math.floor(Math.log(h.size())/Math.log(2));
    }
    
    /**
     * Determines the diameter of the specified heap
     * @param <E> the element type of the heap
     * @param h a binary heap of the specified element type
     * @return the diameter of the heap
     */
    public static <E extends Comparable<E>> int diameter(Heap<E> h)
    {
        if(height(h) < 0)
            return 0;
        int diameter = 2 * height(h);
        if (h.size() > 3*Math.pow(2, height(h)-1)-1)
            diameter++;
        return diameter;
    }
    
    public static void main(String[] args) throws IOException, HeapException
    {
        String usage = "PQParser <data-type> <order-code> <command-file>\n";
        usage += "<data-type>: -s or -S for strings\n";
        usage += "  <order-code>:\n";
        usage += "  -1 min-heap based on lexicographical order\n";
        usage += "  1 max-heap based on lexicographical order\n";
        usage += "  -2 min-heap based on string length\n";
        usage += "  2 max-heap based on string length\n";
        usage += "<data-type>: -i or -I for integers\n";
        usage += "  <order-code>:\n";
        usage += "  -1 min-heap based on numerical order\n";
        usage += "  1 max-heap based on numerical order\n";
        usage += "<command-file>: name of the command file name\n";   
                
        if (args.length != 3)
        {
            System.out.println(usage);
            throw new IllegalArgumentException("Incorrect amount of command line arguments.");
        }
        Scanner inFile = new Scanner(new FileReader(args[2]));
        if (args[0].equals("-i")||args[0].equals("-I"))
        {
            
            Comparator<Integer> cmp;
            if(args[1].equals("1"))
            {
                cmp = (i1,i2) -> i2.compareTo(i1);
            }
            else if(args[1].equals("-1"))
            {
                cmp = (i1,i2) -> i1.compareTo(i2);
            }
            else
            {
                System.out.println(usage);
                throw new IllegalArgumentException("Invalid data-type or order-code was provided.");
            }
            Heap<Integer> parserHeap = new Heap(cmp);
            while(inFile.hasNext())
            {
                String parsedLine = inFile.next();
                if (parsedLine.equals("insert"))
                {
                    int insertedItem = inFile.nextInt();
                    System.out.println("Inserted: " + insertedItem);
                    parserHeap.insert(insertedItem);
                
                }
                else if (parsedLine.equals("delete"))
                {
                    System.out.println("Deleted: " + parserHeap.remove());
                }
                else if (parsedLine.equals("peek"))
                {
                    System.out.println("Top: " + parserHeap.peek());
                }
                else if (parsedLine.equals("stats"))
                {
                    System.out.printf("Stats: size = %d, height = %d, diameter = %d%n", parserHeap.size(), height(parserHeap), diameter(parserHeap));
                }
            }
        }
        else if (args[0].equals("-s")||args[0].equals("-S"))
        {
            Comparator<String> cmp;
            if(args[1].equals("1"))
            {
                cmp = (s1,s2) -> s2.compareTo(s1);
            }
            else if(args[1].equals("-1"))
            {
                cmp = (s1,s2) -> s1.compareTo(s2);
            }
            else if(args[1].equals("2"))
            {
                cmp = (s1,s2) -> s2.length()-s1.length();
            }
            else if(args[1].equals("-2"))
            {
                cmp = (s1,s2) -> s1.length()-s2.length();
            }
            else
            {
                System.out.println(usage);
                throw new IllegalArgumentException("Invalid data-type or order-code was provided.");
            }
            Heap<String> parserHeap = new Heap(cmp);
            while(inFile.hasNext())
            {
                String parsedLine = inFile.next();
                if (parsedLine.equals("insert"))
                {
                    String insertedItem = inFile.next();
                    System.out.println("Inserted: " + insertedItem);
                    parserHeap.insert(insertedItem);              
                }
                else if (parsedLine.equals("delete"))
                {
                    System.out.println("Deleted: " + parserHeap.remove());
                }
                else if (parsedLine.equals("peek"))
                {
                    System.out.println("Top: " + parserHeap.peek());
                }
                else if (parsedLine.equals("stats"))
                {
                    System.out.printf("Stats: size = %d, height = %d, diameter = %d%n", parserHeap.size(), height(parserHeap), diameter(parserHeap));
                }
            }
        }
        else
        {
            System.out.println(usage);
            throw new IllegalArgumentException("Invalid data-type or order-code was provided.");
        }
                
        
        inFile.close();
    }    
}
