package arboretum;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

/**
 * A testbed for an augmented implementation of an AVL tree
 * @author William Duncan, YOUR NAME
 * @see AVLTreeAPI, AVLTreeException
 * <pre>
 * Date: December 20, 2019
 * CSC 3102 Programming Project # 2
 * Instructor: Dr. Duncan 
 * </pre>
 */
public class Arboretum 
{
    public static void main(String[] args) throws FileNotFoundException 
    {
        String usage = "ArboretumAnalyzer <data-type> <order-code> <command-file>\n";
        usage += "<data-type>: -s or -S for strings\n";
        usage += "  <order-code>:\n";
        usage += "  -1 for reversed lexicographical order\n";
        usage += "  1 for lexicographical order\n";
        usage += "  -2 for decreasing string length and reversed lexicographical order\n";
        usage += "  2 for increasing string length and lexicographical order\n";
        usage += "<data-type>: -i or -I for integers\n";
        usage += "  <order-code>:\n";
        usage += "  -1 for decreasing numerical order\n";
        usage += "  1 for increasing numerical order\n";
        usage += "<command-file>: name of the command file name\n";        
        //complete the implementation of this method

    }   
}
