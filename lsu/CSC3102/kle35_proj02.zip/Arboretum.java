package arboretum;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

/**
 * A testbed for an augmented implementation of an AVL tree
 * @author William Duncan, Kha Le
 * @see AVLTreeAPI, AVLTreeException
 * <pre>
 * Date: December 20, 2019
 * CSC 3102 Programming Project # 2
 * Instructor: Dr. Duncan 
 * </pre>
 */
public class Arboretum 
{
    public static void main(String[] args) throws FileNotFoundException 
    {
        String usage = "ArboretumAnalyzer <data-type> <order-code> <command-file>\n";
        usage += "<data-type>: -s or -S for strings\n";
        usage += "  <order-code>:\n";
        usage += "  -1 for reversed lexicographical order\n";
        usage += "  1 for lexicographical order\n";
        usage += "  -2 for decreasing string length and reversed lexicographical order\n";
        usage += "  2 for increasing string length and lexicographical order\n";
        usage += "<data-type>: -i or -I for integers\n";
        usage += "  <order-code>:\n";
        usage += "  -1 for decreasing numerical order\n";
        usage += "  1 for increasing numerical order\n";
        usage += "<command-file>: name of the command file name\n";        
        
        if (args.length != 3)
        {
            System.out.println(usage);
            throw new IllegalArgumentException("Incorrect amount of command line arguments.");
        }
        Scanner inFile = new Scanner(new FileReader(args[2]));
        if (args[0].equals("-i")||args[0].equals("-I"))
        {            
            Comparator<Integer> cmp;
            if(args[1].equals("1"))
            {
                cmp = (i1,i2) -> i1.compareTo(i2);
            }
            else if(args[1].equals("-1"))
            {
                cmp = (i1,i2) -> i2.compareTo(i1);
            }
            else
            {
                System.out.println(usage);
                throw new IllegalArgumentException("Invalid data-type or order-code was provided.");
            }
            AVLTree<Integer> parserAVLTree = new AVLTree(cmp);
            while(inFile.hasNext())
            {
                String parsedLine = inFile.next();
                if (parsedLine.equals("insert"))
                {
                    int insertedItem = inFile.nextInt();
                    System.out.println("Inserted: " + insertedItem);
                    parserAVLTree.insert(insertedItem);              
                }
                else if (parsedLine.equals("delete"))
                {
                    int deletedItem = inFile.nextInt();
                    System.out.println("Deleted: " + deletedItem);
                    parserAVLTree.remove(deletedItem);                                 
                }
                else if (parsedLine.equals("traverse"))
                {
                    System.out.println("In-Order Traversal: ");
                    parserAVLTree.traverse(x -> System.out.printf("%s%n", x));
                }
                else if (parsedLine.equals("stats"))
                {
                    System.out.printf("Stats: size = %d, actual-height = %d, optimal-height = %d, #leaves = %d, full? = %b, perfect? = %b%n", parserAVLTree.size(), parserAVLTree.height(), (int) Math.floor(Math.log(parserAVLTree.size())/Math.log(2)), parserAVLTree.countLeaves(), parserAVLTree.isFull(), parserAVLTree.isPerfect());
                }
                else if (parsedLine.equals("sort"))
                {
                    System.out.println("Sorted List of Tree Items:\n" + parserAVLTree.sort());
                }
            }
        }
        else if (args[0].equals("-s")||args[0].equals("-S"))
        {
            Comparator<String> cmp;
            if(args[1].equals("1"))
            {
                cmp = (s1,s2) -> s1.compareTo(s2);
            }
            else if(args[1].equals("-1"))
            {
                cmp = (s1,s2) -> s2.compareTo(s1);
            }
            else if(args[1].equals("2"))
            {
                cmp = (s1,s2) -> 
                {
                    int diff = s1.length()-s2.length();
                    if (diff == 0)
                        return s1.compareTo(s2);
                    return diff;
                };
            }
            else if(args[1].equals("-2"))
            {
                cmp = (s1,s2) -> 
                {
                    int diff = s2.length()-s1.length();
                    if (diff == 0)
                        return s2.compareTo(s1);
                    return diff;
                };
            }
            else
            {
                System.out.println(usage);
                throw new IllegalArgumentException("Invalid data-type or order-code was provided.");
            }
            AVLTree<String> parserAVLTree = new AVLTree(cmp);
            while(inFile.hasNext())
            {
                String parsedLine = inFile.next();
                if (parsedLine.equals("insert"))
                {
                    String insertedItem = inFile.next();
                    System.out.println("Inserted: " + insertedItem);
                    parserAVLTree.insert(insertedItem);              
                }
                else if (parsedLine.equals("delete"))
                {
                    String deletedItem = inFile.next();
                    System.out.println("Deleted: " + deletedItem);
                    parserAVLTree.remove(deletedItem);                                 
                }
                else if (parsedLine.equals("traverse"))
                {
                    System.out.println("In-Order Traversal: ");
                    parserAVLTree.traverse(x -> System.out.printf("%s%n", x));
                }
                else if (parsedLine.equals("stats"))
                {
                    System.out.printf("Stats: size = %d, actual-height = %d, optimal-height = %d, #leaves = %d, full? = %b, perfect? = %b%n", parserAVLTree.size(), parserAVLTree.height(), (int) Math.floor(Math.log(parserAVLTree.size())/Math.log(2)), parserAVLTree.countLeaves(), parserAVLTree.isFull(), parserAVLTree.isPerfect());
                }
                else if (parsedLine.equals("sort"))
                {
                    System.out.println("Sorted List of Tree Items:\n" + parserAVLTree.sort());
                }
            }
        }
        else
        {
            System.out.println(usage);
            throw new IllegalArgumentException("Invalid data-type or order-code was provided.");
        }                       
        inFile.close();
    }   
}
