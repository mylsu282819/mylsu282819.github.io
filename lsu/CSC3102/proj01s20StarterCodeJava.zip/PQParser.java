package pqparser;

import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;
import java.util.Scanner;

/**
 * A simple parser for the following simple instructions on a binary heap 
 * implementation and the heap sort algorithm using various comparators 
 * @see Heap.H
 * @author Duncan, YOUR NAME
 *  * <pre>
 * COMMANDS [h denotes the heap]
 * command: inserted item
 * executes  -> h.insert(item) and displays "Inserted: item"
 * command: delete
 * displays "Deleted: h.remove()"
 * command: peek
 * displays "Top: h.peek()", where h.peek() returns the top-most item
 * command: stats
 * diplays stats: size = h.size(), height = height(h), diameter = diameter(h)
 * 
 * Date: 99-99-99
 * course: csc 3102
 * programming project 2
 * Instructor: Dr. Duncan
 * </pre>

 */
public class PQParser
{

    /**
     * Determines the height of the specified heap
     * @param <E> the element type of the heap
     * @param h a binary heap of the specified element type
     * @return the height of the heap
     */
    public static <E extends Comparable<E>> int height(Heap<E> h)
    {
        //implement this method
        return -1;
    }
    
    /**
     * Determines the diameter of the specified heap
     * @param <E> the element type of the heap
     * @param h a binary heap of the specified element type
     * @return the diameter of the heap
     */
    public static <E extends Comparable<E>> int diameter(Heap<E> h)
    {
        //implement this method
		return 0;
    }
    public static void main(String[] args) throws IOException, HeapException
    {
        String usage = "PriorityQer <data-type> <order-code> <command-file>\n";
        usage += "<data-type>: -s or -S for strings\n";
        usage += "  <order-code>:\n";
        usage += "  -1 min-heap based on lexicographical order\n";
        usage += "  1 max-heap based on lexicographical order\n";
        usage += "  -2 min-heap based on string length\n";
        usage += "  2 max-heap based on string length\n";
        usage += "<data-type>: -i or -I for integers\n";
        usage += "  <order-code>:\n";
        usage += "  -1 min-heap based on numerical order\n";
        usage += "  1 max-heap based on numerical order\n";
        usage += "<command-file>: name of the command file name\n";        
        //complete the implementation of this method
		
    }    
}
