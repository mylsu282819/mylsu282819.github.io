package digitizer;
import java.util.Scanner;

/**
 *This class decomposes a positive integer into the sum of the product of its digits and their place value and determines whether the number is palindromic.<br>
 *CSC 1350 Lab # 4
 *@author Kha Le
 *@since October 8th, 2019*/

public class Digitizer
{
    public static void main(String[] args)
    {
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter a non-negative integer -> ");
        int number = cin.nextInt();
        if (number < 0)
        {
            System.out.println("Error. Input must be a non-negative integer.");
        }
        else
        {
            System.out.print(number + " = ");
            if (number < 10)
            {
                System.out.println(number);
                System.out.println(number + " is a palindrome.");
            }
            else if (number < 100)
            {       
                System.out.print((number-number%10)/10 + " x 10");
                if (number % 10 != 0)
                {
                    System.out.print(" + " + number%10);
                }
                if ((number-number%10)/10 == number%10)
                {
                    System.out.println("\n" + number + " is a palindrome.");
                }
                else
                {
                    System.out.println("\n" + number + " is not a palindrome.");
                }
            }
            else
            {
                // This section indicates the creation of the placeValueExponent
                // and the placeValue, which is 10^placeValueExponent.
                int placeValue = 100;
                while(number / placeValue >= 10)
                {
                    placeValue *= 10;
                }
                int placeValueExponent = -1;
                for (int i = placeValue; i != 0; i/=10)
                {
                    placeValueExponent++;
                }
                
                // This section detects whether the number is a palindrome or not.
                // If isPalindrome = 1, then the number is a palindrome.
                int isPalindrome = 1;
                int palindromeCounter = 0;
                int divisor1;
                int divisor2;
                while ((placeValueExponent - palindromeCounter) > placeValueExponent/2)
                {
                    divisor1 = placeValue;
                    divisor2 = placeValue;
                    for (int i = 0; i < palindromeCounter; i++)
                    {
                        divisor1 /= 10;
                    }
                    for (int i = 0; i < placeValueExponent - palindromeCounter; i++)
                    {
                        divisor2 /= 10;
                    }
                    if (number/divisor1%10 != number/divisor2%10)
                    {
                        isPalindrome = 0;
                    }
                    palindromeCounter++;
                }
                
                // This section prints out the place value decomposition of the number.
                System.out.print(number/placeValue + " x 10^" + placeValueExponent);
                while(placeValueExponent != 1)
                {
                    placeValueExponent--;
                    placeValue /= 10;
                    if (number/placeValue%10 != 0)
                    {
                        if (placeValueExponent == 1)
                        {
                            System.out.print(" + " + (number/placeValue%10) + " x 10");
                        }
                        else
                        {
                            System.out.print(" + " + (number/placeValue%10) + " x 10^" + placeValueExponent);
                        } 
                    }
                }
                if (number % 10 != 0)
                {
                    System.out.print(" + " + number%10);
                }
                
                // This section prints out whether the number
                // is a palindrome or not.
                if (isPalindrome == 1)
                {
                    System.out.print("\n" + number + " is a palindrome.");
                }
                else
                {
                    System.out.print("\n" + number + " is not a palindrome.");
                }
            }
        }
    }
}
