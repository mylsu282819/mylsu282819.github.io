package staircaseprinter;
/**
 *This program displays a text-based representation of a staircase <br>
 *in two ways. First, it displays the staircase by using a series of<br>
 *’println’statements. Second, it uses one’println’statement to<br>.
 *display the staircase a second time.
 *CSC 1350 Lab # 0<br>
 *@author Kha Le
 *@since September 3rd, 2019
 *Course: CSC 1350 Section: 03
 *Instructor: Dr. Duncan
 */

public class StaircasePrinter
{
    public static void main(String[] args)
    {
        System.out.println("               +---+");
        System.out.println("               |   |");
        System.out.println("           +---+---+");
        System.out.println("           |   |   |");
        System.out.println("       +---+---+---+");
        System.out.println("       |   |   |   |");
        System.out.println("   +---+---+---+---+");
        System.out.println("   |   |   |   |   |");
        System.out.println("   +---+---+---+---+");
        System.out.println("\n"+
                           "               +---+"+
                           "\n"+
                           "               |   |"+
                           "\n"+
                           "           +---+---+"+
                           "\n"+
                           "           |   |   |"+
                           "\n"+
                           "       +---+---+---+"+
                           "\n"+
                           "       |   |   |   |"+
                           "\n"+
                           "   +---+---+---+---+"+
                           "\n"+
                           "   |   |   |   |   |"+
                           "\n"+
                           "   +---+---+---+---+");
    }   
}
