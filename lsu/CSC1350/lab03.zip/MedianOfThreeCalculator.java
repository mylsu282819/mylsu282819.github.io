package medianofthreecalculator;
import java.util.Scanner;

/**
 *The class computes the median of three integers using only the less than operator when comparing them, counts the number of comparisons used to determine the median and prints a strings detailing all the comparisons made along with the logical values. <br>
 *CSC 1350 Lab # 3
 *@author Kha Le
 *@since September 24th, 2019
 */

public class MedianOfThreeCalculator
{
    public static void main(String[] args)
    {
        Scanner sans = new Scanner(System.in);
        System.out.print("Enter three distinct integers to compute their median -> ");
        int first = sans.nextInt(), second = sans.nextInt(), third = sans.nextInt();
        int median;
        int numComparisons = 1;
        String comparisons = first + " < " + second + "?";
        if (first < second)
        {
            
            numComparisons++;
            comparisons += " (T), " + second + " < " + third + "?";
            if (second < third)
            {
                median = second;
                comparisons += " (T);";
            }
            else
            {
                numComparisons++;
                comparisons += " (F), " + first + " < " + third + "?";
                if (first < third)
                {
                    median = third;
                    comparisons += " (T);";
                }
                else
                {
                    median = first;
                    comparisons += " (F);";
                }
            }
        }
        else
        {
            numComparisons++;
            comparisons += " (F), " + second + " < " + third + "?";
            if (second < third)
            {
                numComparisons++;
                comparisons += " (T), " + first + " < " + third + "?";
                if (first < third)
                {
                    median = first;
                    comparisons += " (T);";
                }
                else
                {
                    median = third;
                    comparisons += " (F);";
                }
            }
            else
            {
                median = second;
                comparisons += " (F);";
            }
        }
        
        System.out.println("median("+first+", "+second+", "+third+") = " + median +".");
        System.out.println("Comparisons: "+comparisons+" #Comparisons = "+numComparisons+".");
    }
    
}
