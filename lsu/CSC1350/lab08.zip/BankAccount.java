package bankaccounttester;

public class BankAccount
{
    /**
     * the account balance
     */
    private double balance;
    
    /**
     * Constructs a bank account with a zero balance.
     */
    public BankAccount()
    {
        balance = 0;
    }
    
     /**
     * Creates a bank account with the specified balance
     * @param initialBalance the initial balance
     * @throws IllegalArgumentException when
     * the initial balance is negative
     */
    public BankAccount (double initialBalance) throws java.lang.IllegalArgumentException
    {
        if (initialBalance < 0)
        {
            throw new IllegalArgumentException("Initial balance must be non-negative");
        }
        balance = initialBalance;
    }
    
    /**
     * Creates a bank account based off other bank account's balance
     * @param other a bank account
     */
    public BankAccount (BankAccount other)
    {
        balance = other.balance;
    }
    
    /**
     * Deposits money into the account.
     * @param amount the amount of money to deposit
     * @throws java.lang.IllegalArgumentException when
     * amount is less than 0
     */
    public void deposit (double amount) throws java.lang.IllegalArgumentException
    {
        if (amount < 0)
        {
            throw new IllegalArgumentException("Deposit must be non-negative");
        }
        balance += amount;
    }
    
    /**
     * Withdraws money from the account.
     * @param amount the amount of money to withdraw
     * @throws java.lang.IllegalArgumentException when
     * amount is greater than balance
     */
    public void withdraw (double amount) throws java.lang.IllegalArgumentException
    {
       if (amount > balance)
        {
            throw new IllegalArgumentException("overdraft withdrawal is not allowed");
        } 
       balance -= amount;
    }
    
    /**
     * Gets the account balance.
     * @return the account balance
     */
    public double getBalance()
    {
        return balance;
    }
    
    /**
     * Returns a string representation of this bank account in the format "BankAccount[balance = ...]",
     * where ... denotes the balance.
     * @return a string representation of this bank account in the format "BankAccount[balance = ...]", where ... denotes the balance.
     */
    public String toString()
    {
        return String.format("BankAccount[balance = %.2f]",balance);
    }
}
