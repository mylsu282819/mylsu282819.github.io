package bankaccounttester;
import java.util.Scanner;

/**
 *Describes a bank account whose balance can be changed by deposits and withdrawals. <br>
 *CSC 1350 Lab # 8
 *@author Kha Le
 *@since November 12th, 2019
 *@see BankAccount (ADD THIS TAG ONLY IN THE BankAccountTester Javadoc HEADER COMMENTS)
 */

public class BankAccountTester
{
    public static void main(String[] args)
    {
        Scanner cin = new Scanner(System.in);
        
        System.out.print("Enter the initial balance for a savings account -> ");
        double amount = cin.nextDouble();
        BankAccount savings = new BankAccount(amount);
        BankAccount checking = new BankAccount(amount + 500);
        System.out.printf("Your savings account balance is $%.2f.%nYour checkings account balance is $%.2f.%n%n", savings.getBalance(), checking.getBalance());
        
        System.out.print("Enter an amount to transfer from checking to savings -> ");
        double amount2 = cin.nextDouble();
        savings.deposit(amount2);
        checking.withdraw(amount2);
        System.out.printf("Your savings account balance is $%.2f.%nYour checkings account balance is $%.2f.%n%n", savings.getBalance(), checking.getBalance());
        
        System.out.printf("Does the savings and check accounts have the same balance? %b%n%n", savings.getBalance() == checking.getBalance());
        
        BankAccount youngAdult = new BankAccount(savings);
        System.out.printf("Savings a/c: %s%nChecking a/c: %s%nYoung Adult a/c: %s%n", savings, checking, youngAdult);
    }
    
}
