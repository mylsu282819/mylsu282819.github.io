package quadraticsolver;
import java.util.Scanner;

/**
 *It calculates stuff for functions of the form ax^2+bx+c, such as its roots, axis of symmetry, discriminant, and intercepts.
 *Course: CS1350 <br>
 *Section: 03 <br>
 *PAWS ID: kle35 <br>
 *Lab #: 2 <br>*Instructor: Dr. Duncan <br>
 *@author Kha Le
 *@since August 17th, 2019
 */
public class QuadraticSolver
{

    public static void main(String[] args)
    {
        Scanner sans = new Scanner(System.in);
 
        System.out.println("To solve the quadratic equation, aX^2 + bx + c = 0,\nenter the non-zero coefficient of its quadratic term, a, the\ncoefficient of its linear term, b, and its constant term, c:");
       
        double a = sans.nextDouble(), b = sans.nextDouble(), c = sans.nextDouble();
        double discrim = Math.pow(b,2)-4*a*c;
        double axisOfSym = (-b)/(2*a);
        double vertexY = a*Math.pow(axisOfSym,2)+b*axisOfSym+c;
        double rootOne = (-b+Math.sqrt(discrim))/(2*a);
        double rootTwo = (-b-Math.sqrt(discrim))/(2*a);
        System.out.printf("%nDiscriminant: %.2f%nAxis of Symmetry: x = %.2f%nVertex: (%.2f, %.2f)%ny-intercept: (0.00, %.2f)%nx-intercept: (%.2f, 0.00) and (%.2f, 0.00)%nroots: {%.2f, %.2f}", discrim, axisOfSym, axisOfSym, vertexY, c, rootOne, rootTwo, rootOne, rootTwo);
    }
    
}
