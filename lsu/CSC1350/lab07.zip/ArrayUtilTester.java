package arrayutiltester;
import java.util.Scanner;

/**
 *This class implements its own version of the copyOf, arrayCopy, and toString methods. <br>
 *CSC 1350 Lab # 7
 *@author Kha Le
 *@since November 5th, 2019
 *@see ArrayUtil
 */

public class ArrayUtilTester
{
    public static void main(String[] args)
    {
        // Initializing Scanner
        Scanner cin = new Scanner(System.in);
        
        // Initializing ArrayUtil
        ArrayUtil aru = new ArrayUtil();
        
        // Prompt for first array size
        System.out.print("Enter the size of the first array -> ");
        int firstSize = cin.nextInt();
        
        // Prompt for first array entries
        System.out.println("Enter the entries of the array separated by spaces: ");
        int[] first = new int[firstSize];
        
        // Creating the first, second, and third arrays
        for (int i = 0; i < first.length; i++)
        {
            first[i] = cin.nextInt();
        }
        int[] second = aru.copyOf(first, first.length*2);
        int[] third = aru.copyOf(first, first.length/2);
        
        // Printing the first, second, and third arrays, along with prompt for the 'fourthIndex'
        System.out.printf("%nfirst: %S%nsecond: %S%nthird: %S%n%nEnter an index of 'fourth' at which to copy 'first' -> ", aru.toString(first), aru.toString(second), aru.toString(third));
        int[] fourth = new int[firstSize * 2];
        int fourthIndex = cin.nextInt();
        
        // Creating fourth and fifth arrays
        aru.arraycopy(first, 0, fourth, fourthIndex, firstSize);
        int[] fifth = new int [firstSize * 2];
        aru.arraycopy(first, 0, fifth, 0, firstSize);
        aru.arraycopy(first, 0, fifth, fifth.length/2, firstSize);
        
        // Printing the first, fourth, and fifth arrays
        System.out.printf("%nfirst: %S%nfourth: %S%nfifth: %S%n", aru.toString(first), aru.toString(fourth), aru.toString(fifth));
        
    }
    
}
