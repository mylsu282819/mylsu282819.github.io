package arrayutiltester;

public class ArrayUtil
{
    /**
     * Returns a string representation of the contents of the specified array.
     * The string representation consists of a list of the array's elements, 
     * enclosed in square brackets ("[]"). Adjacent elements are separated by
     * the characters ", " (a comma followed by a space). Elements are converted
     * to strings. Returns "null" if arry is null.
     * @param arry - the array whose string representation to return
     * @return a string representation of arry
     */
    public static String toString(int[] arry)
    {
        if (arry == null)
        {
            return null;
        }
        String arrayString = "[" + arry[0];
        for (int i = 1; i < arry.length; i++)
        {
            arrayString += ", " + arry[i];
        }
        arrayString += "]";
        return arrayString;
    }
    
    /**
     * Copies the specified array, truncating or padding with zeros
     * (if necessary) so the copy has the specified length.
     * @param original - the array to be copied
     * @param newLength - the length of the copy to be returned
     * @return a copy of the original array, truncated or padded with
     * zeroes to obtain the specified length
     * @throws IllegalArgumentException when:
     * 1. newLength is negative
     * 2. if original is null
     */
    public static int[] copyOf(int[] original, int newLength)
    {
        if (newLength < 0 || original == null)
        {
            throw new IllegalArgumentException("Invalid argument");
        }
        int[] copy = new int[newLength];
        for (int i = 0; i < original.length && i < newLength; i++)
        {
            copy[i] = original[i];
        }
        return copy;
    }
    
    /**
     * Copies an array from the specified source array, beginning at 
     * the specified position, to the specified position of the
     * destination array.
     * @param src - the source array.
     * @param srcPos - starting position in the source array.
     * @param dest - the destination array.
     * @param destPos - starting position in the destination data.
     * @param length - the number of array elements to be copied.
     * @throws IllegalArgumentException when
     * 1. if either src or dest is null.
     * 2. copying would cause access of data outside array bounds when
     *    any of the following is true:
     *    length < 0, srcPos < 0, destPos < 0, srcPos + length > src.length,
     *    destPos + length > dest.length
     */
    public static void arraycopy(int[] src, int srcPos, int[] dest, int destPos, int length)
    {
        if (src == null || dest == null || length < 0 || srcPos < 0 || destPos < 0 || (srcPos + length) > src.length || (destPos + length) > dest.length)
        {
            throw new IllegalArgumentException("Invalid argument");
        }
        for (int i = 0; i < length; i++)
        {
            dest[destPos + i] = src[srcPos + i]; 
        }
    }
}
