package bubblesorttester;

import java.util.Arrays;

public class Sorter
{
    
    /**
     * Sorts an array of integers in non-decreasing order.
     * @param data an array of integers
     * @version 1
     */
    /*
    public static void bubbleSort(int[] data)
    {
        boolean notFinished;
        int partitionIndex = data.length - 1, temp;
        do
        {
            notFinished = false;
            for (int i = 0; i < partitionIndex; i++)
            {
                if (data[i] > data[i+1])
                {
                    temp = data[i];
                    data[i] = data[i+1];
                    data[i+1] = temp;
                    notFinished = true;
                }
            }
            partitionIndex--;
        }while(notFinished);
    }
    */
    
    /**
     * Sorts an array of integers in non-decreasing order and prints the array
     * after each pass.
     * @param data an array of integers
     * @version 2
     */
    /*
    public static void bubbleSort(int[] data)
    {
        boolean notFinished;
        int partitionIndex = data.length - 1, temp;
        System.out.println();
        do
        {
            notFinished = false;
            for (int i = 0; i < partitionIndex; i++)
            {
                if (data[i] > data[i+1])
                {
                    temp = data[i];
                    data[i] = data[i+1];
                    data[i+1] = temp;
                    notFinished = true;
                }
            }
            partitionIndex--;
            System.out.println(Arrays.toString(data));
        }while(notFinished);
        System.out.println();
    }
    */
    
    /**
     * Sorts an array of integers in non-decreasing order, prints the array
     * after each pass, and prints the pairs of elements that are compared
     * during each pass.
     * @param data an array of integers
     * @version 3
     */
    /*
    public static void bubbleSort(int[] data)
    {
        boolean notFinished;
        int partitionIndex = data.length - 1, temp;
        System.out.println();
        do
        {
            notFinished = false;
            for (int i = 0; i < partitionIndex; i++)
            {
                System.out.printf("(%d,%d) ", data[i], data[i+1]);
                if (data[i] > data[i+1])
                {
                    temp = data[i];
                    data[i] = data[i+1];
                    data[i+1] = temp;
                    notFinished = true;
                }
            }
            partitionIndex--;
            System.out.println("\n"+Arrays.toString(data));
        }while(notFinished);
        System.out.println();
    }
    */
    
    /**
     * Sorts an array of integers in non-increasing order, prints the array
     * after each pass, and prints the pairs of elements that are compared
     * during each pass.
     * @param data an array of integers
     * @version 4
     */
    /*
    public static void bubbleSort(int[] data)
    {
        boolean notFinished;
        int partitionIndex = data.length - 1, temp;
        System.out.println();
        do
        {
            notFinished = false;
            for (int i = 0; i < partitionIndex; i++)
            {
                System.out.printf("(%d,%d) ", data[i], data[i+1]);
                if (data[i] < data[i+1])
                {
                    temp = data[i];
                    data[i] = data[i+1];
                    data[i+1] = temp;
                    notFinished = true;
                }
            }
            partitionIndex--;
            System.out.println("\n"+Arrays.toString(data));
        }while(notFinished);
        System.out.println();
    }
    */
    
    /**
     * Sorts an array of integers in non-increasing order by scanning the array
     * leftward, prints the array after each pass, and prints the pairs of
     * elements that are compared during each pass.
     * @param data an array of integers
     * @version 5
     */
    public static void bubbleSort(int[] data)
    {
        boolean notFinished;
        int partitionIndex = 0, temp;
        System.out.println();
        do
        {
            notFinished = false;
            for (int i = data.length - 1; i > partitionIndex; i--)
            {
                System.out.printf("(%d,%d) ", data[i-1], data[i]);
                if (data[i-1] < data[i])
                {
                    temp = data[i-1];
                    data[i-1] = data[i];
                    data[i] = temp;
                    notFinished = true;
                }
            }
            partitionIndex++;
            System.out.println("\n"+Arrays.toString(data));
        }while(notFinished);
        System.out.println();
    }
    
}

