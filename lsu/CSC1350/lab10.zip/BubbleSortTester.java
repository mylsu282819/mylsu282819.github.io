package bubblesorttester;
import java.util.Arrays;

/**
 *Uses various versions of bubblesort to sort an array. <br>
 *CSC 1350 Lab # 10
 *@author Kha Le
 *@since November 26th, 2019
 *@see Sorter (ADD THIS TAG ONLY IN THE BubbleSortTester Javadoc HEADER COMMENTS)
 */

public class BubbleSortTester
{
    public static void main(String[] args)
    {
       int[] data = {2, 4, 5, 6, 4, 5, 3, 5, 3};
       // int[] data = {1, 2, 3, 4, 5, 6, 7, 8, 9};
       // int[] data = {9, 8, 7, 6, 5, 4, 3, 2, 1};
       System.out.println("Initial Data: " + Arrays.toString(data));
       Sorter.bubbleSort(data);
       System.out.println("Sorted Data: " + Arrays.toString(data));
       
    }
    
}
