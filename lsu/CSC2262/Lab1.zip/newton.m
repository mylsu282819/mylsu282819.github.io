function solution = newton(f, fp, guess, accuracy)
    thetanew = guess;
    thetaold = guess+1;
    while (abs(thetaold-thetanew) > accuracy)
        thetaold = thetanew;
        thetanew = thetaold - f(thetaold)/fp(thetaold);
    end
    solution = thetanew;
end