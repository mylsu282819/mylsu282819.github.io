h = 250;
x = 775;
g = 9.81;
for v=75:5:85
    f = @(theta) h*(cos(theta))^2+(x/2)*sin(2*theta)-(g*x^2)/(2*v^2);
    fp = @(theta) -2*h*cos(theta)*sin(theta)+x*cos(2*theta);
    for k=0:pi/180:pi/2
        if (f(k)*f(k+pi/180) < 0)
            root = newton(f, fp, (k+pi/180+k)/2, 1e-7);
            t = v*(sin(root))/g+((v^2)*((sin(root))^2)/(g^2)+2*h/g)^(1/2);
            ymax = h + ((v^2)*(sin(root))^2)/(2*g);
            fprintf("v0 = %f  theta = %f  t = %f  ymax = %f\n", v, root*180/pi, t, ymax)
        end
        
    end
end


