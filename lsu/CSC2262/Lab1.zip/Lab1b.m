f = @(x) 728*x^4-8249*x^3+33660*x^2-57996*x+34992;
fp = @(x) 2912*x^3-24747*x^2+67320*x-57996;


for k=0:0.1:5
    if (f(k)*f(k+0.1) < 0)
        root = newton(f, fp, (k+0.1+k)/2, 1e-7);
        fprintf("x = %f\n", root)
    elseif (f(k)==0)
        fprintf("x = %f\n", k)
    end

end

