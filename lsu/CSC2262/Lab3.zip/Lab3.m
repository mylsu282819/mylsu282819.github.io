% Kha Le
% CSC 2262
% cs226243
% Lab 3
r1 = 2.4;
r2 = 2.2;
x = 2.67;
y = 1.5;
guess1 = 20*pi/180;
guess2 = 70*pi/180;
guess3 = 30*pi/180;
accuracy = 1e-7;
count = 0;
for (z = 0 : 0.01 : 2.5)
    count = count + 1;
    
    f1 = @(t1, t2, phi) r1*sin(t1)*cos(phi)+r2*sin(t1+t2)*cos(phi)-x;
    f2 = @(t1, t2, phi) r1*sin(t1)*sin(phi)+r2*sin(t1+t2)*sin(phi)-y;
    f3 = @(t1, t2) r1*cos(t1)+r2*cos(t1+t2)-z;
    
    df1dt1 = @(t1, t2, phi) r1*cos(t1)*cos(phi)+r2*cos(t1+t2)*cos(phi);
    df1dt2 = @(t1, t2, phi) r2*cos(t1+t2)*cos(phi);
    df1dphi = @(t1, t2, phi) -1*r1*sin(t1)*sin(phi)-r2*sin(t1+t2)*sin(phi);
    df2dt1 = @(t1, t2, phi) r1*cos(t1)*sin(phi)+r2*cos(t1+t2)*sin(phi);
    df2dt2 = @(t1, t2, phi) r2*cos(t1+t2)*sin(phi);
    df2dphi = @(t1, t2, phi) r1*sin(t1)*cos(phi)+r2*sin(t1+t2)*cos(phi);
    df3dt1 = @(t1, t2) -1*r1*sin(t1)-r2*sin(t1+t2);
    df3dt2 = @(t1, t2) -r2*sin(t1+t2);
    df3dphi = 0;
    
    [t1, t2, phi] = newton3(f1, f2, f3, df1dt1, df1dt2, df1dphi, df2dt1, df2dt2, df2dphi, df3dt1, df3dt2, df3dphi, guess1, guess2, guess3, accuracy)
    
    r1h = r1*sin(t1);
    r1z = r1*cos(t1);
    r2h = r2*sin(t1+t2);
    r2z = r2*cos(t1+t2);
    r1x = r1h*cos(phi);
    r1y = r1h*sin(phi);
    r2x = r2h*cos(phi);
    r2y = r2h*sin(phi);
    
    liner1x = [0 r1x];
    liner1y = [0 r1y];
    liner1z = [0 r1z];
    liner2x = [r1x r1x+r2x];
    liner2y = [r1y r1y+r2y];
    liner2z = [r1z r1z+r2z];
    
    plot3(liner1x, liner1y, liner1z, 'r', liner2x, liner2y, liner2z, 'b', x, y, z, 'ko', 'Markersize', 10);
    grid on
    box on
    axis([0 3 0 3 0 3]);

    set(gca, 'xtick', 0 : 3);
    set(gca, 'ytick', 0 : 3);
    set(gca, 'ztick', 0 : 3);
    
    xlabel('x')
    ylabel('y')
    zlabel('z')
    title('Lab 3')
    pause(0.01);

    if (count == 1)
        pause(8);
    end

end











