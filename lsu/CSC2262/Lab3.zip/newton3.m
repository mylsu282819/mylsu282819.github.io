function [t1, t2, phi] = newton3(f1, f2, f3, df1dt1, df1dt2, df1dphi, df2dt1, df2dt2, df2dphi, df3dt1, df3dt2, df3dphi, guess1, guess2, guess3, accuracy)
t1_new = guess1;
t1_old = guess1 + 1;
t2_new = guess2;
t2_old = guess2 + 1;
phi_new = guess3;
phi_old = guess3 + 1;
while(abs(t1_new - t1_old) >= accuracy || abs(t2_new - t2_old) >= accuracy || abs(phi_new - phi_old) >= accuracy)
    t1_old = t1_new;
    t2_old = t2_new;
    phi_old = phi_new;
    d = [f1(t1_old, t2_old, phi_old); f2(t1_old, t2_old, phi_old); f3(t1_old, t2_old)];
    a = [df1dt1(t1_old, t2_old, phi_old) df1dt2(t1_old, t2_old, phi_old) df1dphi(t1_old, t2_old, phi_old); df2dt1(t1_old, t2_old, phi_old) df2dt2(t1_old, t2_old, phi_old) df2dphi(t1_old, t2_old, phi_old); df3dt1(t1_old, t2_old) df3dt2(t1_old, t2_old) df3dphi]; 
    p = inv(a)*d;
    t1_new = t1_old - p(1);
    t2_new = t2_old - p(2);
    phi_new = phi_old - p(3);
end
t1 = t1_new;
t2 = t2_new;
phi = phi_new;
