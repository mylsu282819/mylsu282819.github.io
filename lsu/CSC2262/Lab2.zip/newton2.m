function [t2 t3] = newton2(f1, f2, df1d2, df1d3, df2d2, df2d3, guess1, guess2, accuracy)

theta3_new = guess2;
theta3_old = guess2 + 1;
theta2_new = guess1;
theta2_old = guess1 + 1;
while(abs(theta3_new - theta3_old) >= accuracy && abs(theta2_new - theta2_old) >= accuracy)
    theta3_old = theta3_new;
    theta2_old = theta2_new;
    d = [f1(theta2_old, theta3_old); f2(theta2_old, theta3_old)];
    a = [df1d2(theta2_old), df1d3(theta3_old); df2d2(theta2_old), df2d3(theta3_old)];
    p = inv(a)*d;
    theta2_new = theta2_old - p(1, 1);
    theta3_new = theta3_old - p(2, 1);
end
t2 = theta2_new;
t3 = theta3_new;
    

