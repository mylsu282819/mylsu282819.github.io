% Kha Le
% CSC 2262
% cs226243
% Lab 2
r1 = 4.14;
r2 = 3.25;
r3 = 3.77;
r4 = 2.57;
guess1 = 75*pi/180;
guess2 = 30*pi/180;
accuracy = 1e-7;
count = 0;
for (t4 = 84*pi/180 : 1*pi/180 : 804*pi/180)
    count = count + 1;
    f1 = @(t2, t3) r2*cos(t2) + r3*cos(t3) + r4*cos(t4) - r1;
    f2 = @(t2, t3) r3*sin(t3) + r4*sin(t4) - r2*sin(t2);
    df1d2 = @(t2) -1*r2*sin(t2);
    df1d3 = @(t3) -1*r3*sin(t3);
    df2d2 = @(t2) -1*r2*cos(t2);
    df2d3 = @(t3) r3*cos(t3);
    [t2 t3] = newton2(f1, f2, df1d2, df1d3, df2d2, df2d3, guess1, guess2, accuracy);
    r2x = r2*cos(t2);
    r3x = r3*cos(t3);
    r4x = r4*cos(t4);
    r2y = r2*sin(t2);
    r3y = r3*sin(t3);
    r4y = r4*sin(t4);
    line2x = [0 r2x];
    line2y = [0 r2y];
    line1x = [0 r1];
    line1y = [0 0];
    line3x = [r2x r2x+r3x];
    line3y = [r2y r4y];
    line4x = [r2x+r3x r1];
    line4y = [r4y 0];
    plot(line1x, line1y, 'k', line2x, line2y, 'r', line3x, line3y, 'g', line4x, line4y, 'b');
    axis([-3 7 -3 7]);
    set(gca, 'xtick', -3 : 1 : 7);
    set(gca, 'ytick', -3 : 1 : 7);
    pbaspect([1 1 1]);
    xlabel('x')
    ylabel('y')
    title('Lab 2')
    pause(0.01);

    if (count == 1)
        pause(7);
    end

end














