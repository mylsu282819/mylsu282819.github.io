package auxmathtester;
import java.util.Scanner;

/**
 *This class computes ln(x) log_b(x) e^x and x^n using methods from a different class.<br>
 *CSC 1350 Lab # 6
 *@author Kha Le
 *@since October 22nd, 2019
 *@see AuxMath
 */



public class AuxMathTester
{
    public static void main(String[] args)
    {
        Scanner cin = new Scanner(System.in);
        AuxMath amx = new AuxMath();
        
        System.out.print("Enter x to compute ln(x) -> ");
        double x = cin.nextDouble();
        System.out.printf("ln(%.1f) = %.10f%n", x, amx.nLog(x));
        
        System.out.print("Enter x and b to compute log_b(x) -> ");
        x = cin.nextDouble();
        double y = cin.nextDouble();
        System.out.printf("log_%.1f(%.1f) = %.10f%n", y, x, amx.bLog(x,y));
        
        System.out.print("Enter x to compute e^x -> ");
        x = cin.nextDouble();
        System.out.printf("e^%.1f = %.10f%n", x, amx.xpon(x)); 
        
        System.out.print("Enter x and n to compute x^n -> ");
        x = cin.nextDouble();
        y = cin.nextDouble();
        System.out.printf("%.1f^%.1f = %.10f%n", x, y, amx.pwr(x,y));
        
    }
    
}
