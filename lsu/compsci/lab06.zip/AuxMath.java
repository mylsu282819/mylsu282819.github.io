package auxmathtester;

public class AuxMath 
{
    /**
    *Computes the natural log of the specified number using a series approximation.*
    *@param x a positive number
    *@return the series approximation of ln(x) using the first 10000 terms or NaN
    *when x is not a positive number
    */
    public static double nLog(double x)
    {
        if (x <= 0)
        {
            return Double.NaN;
        }
        else
        {
            double sum = 0;
            for (int i = 0; i < 10000; i++)
            {
                double quot = (x-1)/(x+1);
                for (int j = 0; j < 2*i; j++)
                {
                    quot *= (x-1)/(x+1);
                }
                sum += quot/(2*i+1);
            }
            return 2*sum;
        }   
    }
    
    /**
     *Computes the exponential of the specified number using a series approximation.
     *@param x a number
     *@return the series approximation of e^x
     */public static double xpon(double x)
     {
         if (x == -1)
         {
             return 0.3678794411;
         }
         else if (x == 0)
         {
             return 1;
         }
         else if (x == 1)
         {
             return 2.7182818284;
         }
         else
         {
             double sum = 1 + x;
             for (int i = 0; i < 398; i++)
             {
                 double power = x;
                 for (int j = 0; j < i+1; j++)
                 {
                     power *= x;
                 }
                 double prod = 1;
                 for (int j = 0; j <= i; j++)
                 {
                     prod *= (j+2);
                 }
                 sum += power/prod;
             }
             return sum;
         }
     }
          
    /**
     *Computes the logarithm of the specified to the specified base
     *@param x a positive number
     *@param b the base of the logarithm
     *@return log_b(x) or NaN if log_b(x) is undefined
     */
     public static double bLog(double x, double b)      
     {
         if (b > 0 && b != 1)
         {
            return nLog(x)/nLog(b);
         }
         else
         {
            return Double.NaN;
             
         }
     }
     
    /**
     *Computes the specified power of the given base
     *@param x the base of the power
     *@param n the exponent of the power
     *@return x^n or NaN if x^n is undefined
     */public static double pwr(double x, double n)
     {
         if (x == 0)
         {
             if (n <= 0)
             {
                 return Double.NaN;
             }
             else
             {
                 return 0;
             }
         }
         else
         {
             if (x == 1)
             {
                 return 1;
             }
             else
             {
                if (n == 0)
                {
                    return 1;
                }
                else if (n == 1)
                {
                    return x;
                }
                else if (n == -1)
                {
                    return 1/x;
                }
                else if (x > 0)
                {
                    return xpon(n*nLog(x));
                }
                else if (x < 0 && (int)(n)!= n)
                {
                    return Double.NaN;
                }
                else if (x < 0 && (n % 2 == 0))
                {
                    return xpon(n*nLog(-1*x));
                }
                else
                {
                    return -1*xpon(n*nLog(-1*x));
                }
             }
             
         }
         
     }
     
}
