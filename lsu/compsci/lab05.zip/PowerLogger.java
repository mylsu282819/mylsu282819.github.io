package powerlogger;
import java.util.Scanner;

/**
 *This class computes ln(x) log_b(x) e^x and x^n<br>
 *CSC 1350 Lab # 5
 *@author Kha Le
 *@since October 15th, 2019*/


public class PowerLogger
{
    /**
    *Computes the natural log of the specified number using a series approximation.*
    *@param x a positive number
    *@return the series approximation of ln(x) using the first 10000 terms or NaN
    *when x is not a positive number
    */
    public static double nLog(double x)
    {
        if (x <= 0)
        {
            return Double.NaN;
        }
        else
        {
            double sum = 0;
            for (int i = 0; i < 10000; i++)
            {
                double quot = (x-1)/(x+1);
                for (int j = 0; j < 2*i; j++)
                {
                    quot *= (x-1)/(x+1);
                }
                sum += quot/(2*i+1);

            }
            return 2*sum;
        }
        
        
    }
    
    /**
     *Computes the exponential of the specified number using a series approximation.
     *@param x a number
     *@return the series approximation of e^x
     */public static double xpon(double x)
     {
         if (x == -1)
         {
             return 0.3678794411;
         }
         else if (x == 0)
         {
             return 1;
         }
         else if (x== 1)
         {
             return 2.7182818284;
         }
         else
         {
             double sum = 1 + x;
             for (int i = 0; i < 398; i++)
             {
                 double power = x;
                 for (int j = 0; j < i+1; j++)
                 {
                     power *= x;
                 }
                 double prod = 1;
                 for (int j = 0; j <= i; j++)
                 {
                     prod *= (j+2);
                 }
                 sum += power/prod;
             }
             return sum;
         }

     }
            
    /**
     *Computes the logarithm of the specified to the specified base
     *@param x a positive number
     *@param b the base of the logarithm
     *@return log_b(x) or NaN if log_b(x) is undefined
     */
     public static double bLog(double x, double b)      
     {
         if (b <= 0)
         {
             return Double.NaN;
         }
         else
         {
             return nLog(x)/nLog(b);
         }
     }
     
    /**
     *Computes the specified power of the given base
     *@param x the base of the power
     *@param n the exponent of the power
     *@return x^n or NaN if x^n is undefined
     */public static double pwr(double x, double n)
     {
         if (x == 0 && n < 0)
         {
             return Double.NaN;
         }
         else if (x == 0 && n > 0)
         {
             return 0;
         }
         else if (x > 0)
         {
             return xpon(n*nLog(x));
         }
         else
         {
             return xpon(n*nLog(-1*x));
         }
     }

    public static void main(String[] args)
    {
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter x to compute ln(x) -> ");
        double x = cin.nextDouble();
        System.out.printf("ln(%f) = %.10f%n", x, nLog(x));
        
        System.out.print("Enter x and b to compute log_b(x) -> ");
        x = cin.nextDouble();
        double y = cin.nextDouble();
        System.out.printf("log_%f(%f) = %.10f%n", y, x, bLog(x,y));
        
        System.out.print("Enter x to compute e^x -> ");
        x = cin.nextDouble();
        System.out.printf("e^%f = %.10f%n", x, xpon(x)); 
        
        System.out.print("Enter x and n to compute x^n -> ");
        x = cin.nextDouble();
        y = cin.nextDouble();
        System.out.printf("%f^%f = %.10f%n", x, y, pwr(x,y));
        
    }
    
}
