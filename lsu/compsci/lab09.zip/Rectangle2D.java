package rectangle2dtester;
import java.awt.geom.Point2D;

public class Rectangle2D
{
    /**
     * The height of this Rectangle2D.
     */
    private double height;
    
    /**
     * The width of this Rectangle2D.
     */
    private double width;
    
    /**
     * The X coordinate of this Rectangle2D.
     */
    private double x;
    
    /**
     * The Y coordinate of this Rectangle2D.
     */
    private double y;
    
    /**
     * Creates a rectangle whose location is (0,0) and and width and height are both 0.
     */
    public Rectangle2D()
    {
        height = 0;
        width = 0;
        x = 0;
        y = 0;
    }
    
    /**
     * Creates a rectangle using the specified parameters.
     * @param xLoc the x-coordinate of the location
     * @param yLoc the y-coordinate of the location
     * @param w the width of the rectangle
     * @param h the height of the rectangle
     */
    public Rectangle2D(double xLoc, double yLoc, double w, double h)
    {
        height = h;
        width = w;
        x = xLoc;
        y = yLoc;
    }
    
    /**
     * Creates a rectangle using the specified parameters
     * @param loc the location of the top-left corner of the rectangle
     * @param w the width of the rectangle
     * @param h the height of the rectangle
     */
    public Rectangle2D(Point2D.Double loc, double w, double h)
    {
        height = h;
        width = w;
        x = loc.getX();
        y = loc.getY();
    }
    
    /**
     * Gives the height of this rectangle.
     * @return the height of this rectangle
     */
    public double getHeight()
    {
        return height;
    }
    
    /**
     * Gives the width of this rectangle.
     * @return the width of this rectangle
     */
    public double getWidth()
    {
        return width;
    }
    
    /**
     * Gives the location of this rectangle.
     * @return the point representing the top-left corner of this rectangle.
     */
    public Point2D.Double getLocation()
    {
        return new Point2D.Double(x, y);
    }
    
    /**
     * Gives the x-coordinate of the location of this rectangle
     * @return the x-coordinate of the location of this rectangle.
     */
    public double getX()
    {
        return x;
    }
    
    /**
     * Gives the y-coordinate of the location of this rectangle
     * @return the y-coordinate of the location of this rectangle.
     */
    public double getY()
    {
        return y;
    }
    
    /**
     * Modifies a rectangle using the specified parameters.
     * @param xLoc the x-coordinate of the new location
     * @param yLoc the y-coordinate of the new location
     * @param w the new width of this rectangle
     * @param h the new height of this rectangle
     */
    public void setRect2D(double xLoc, double yLoc, double w, double h)
    {
        height = h;
        width = w;
        x = xLoc;
        y = yLoc;
    }
    
    /**
     * Gives a string representation of this rectangle in the format Rectangle2D[x=..,y=..,width=..,height=..] 
     * where .. denotes the numeric value of each field. For a Rectangle2D object at (5.0,7.0) whose width is 75.2 and height=40.51, 
     * the following string is returned: Rectangle2D[x=5.0,y=7.0,width=75.2,height=40.51]
     * @return a formatted string representing this rectangle in the format Rectangle2D[x=..,y=..,width=..,height=..]
     */
    public String toString()
    {
        return String.format("Rectangle2D[x=%f,y=%f,width=%f,height=%f]", x, y, width, height);
    }
    
    /**
     * Determines whether a point with the specified coordinates is in this rectangle.
     * @param xCoord the x-coordinate of the point
     * @param yCoord the y-coordinate of the point
     * @return true when the point with the specified x-y coordinates is in this rectangle; otherwise, false.
     */
    public boolean contains(double xCoord, double yCoord)
    {
        return (xCoord > x && xCoord < (x + width) && yCoord > y && yCoord < (y+height));
    }
    
    /**
     * Determines whether this rectangle and the specified rectangle have the same location and dimension.
     * @param r a Rectangle2D object
     * @return true when the specified rectangle2D object is equal to this rectangle; otherwise, false.
     */
    public boolean equals(Rectangle2D r)
    {
        return (x == r.getX() && y == r.getY() && width == r.getWidth() && height == r.getHeight());
    }
    
}
