package rectangle2dtester;
import java.util.Scanner;
import java.awt.geom.Point2D;

/**
 *Describes a rectangle in a graphical coordinate plane. <br>
 *CSC 1350 Lab # 9
 *@author Kha Le
 *@since November 19th, 2019
 *@see Rectangle2D (ADD THIS TAG ONLY IN THE BankAccountTester Javadoc HEADER COMMENTS)
 */

public class Rectangle2DTester
{
    public static void main(String[] args)
    {
        Scanner cin = new Scanner(System.in);
        
        // Prompts user for the x and y coordinates and then inputs it into a Point2D.Double location
        System.out.print("Enter the x- and y-coordinates of the top-left corner -> ");
        Point2D.Double inputLocation = new Point2D.Double(cin.nextDouble(), cin.nextDouble());
        
        // Prompts user for width and height and inputs it, along with the inputLocation, into the smaller rectangle
        System.out.print("Enter the width and height of the rectangle -> ");
        Rectangle2D smallRect = new Rectangle2D(inputLocation, cin.nextDouble(), cin.nextDouble());
        
        // Create a larger rectangle that has a path of uniform width 15 pixels and is concentric with smaller rectangle
        inputLocation.setLocation(smallRect.getX()-15, smallRect.getY()-15);
        Rectangle2D largeRect = new Rectangle2D(inputLocation, smallRect.getWidth()+30, smallRect.getHeight()+30);
        
        // Prints information about big and small rectangle, their perimeters, and the shaded region between them
        System.out.printf("%nAfter creating the two rectangles:%nBig rectangle: [x = %.2f; y = %.2f; w = %.2f; h = %.2f]%nSmall rectangle: [x = %.2f; y = %.2f; w = %.2f; h = %.2f]%nThe perimeter of the big rectangle is %.2f.%nThe perimeter of the small rectangle is %.2f.%nThe area of the shaded region is %.2f.%n", largeRect.getX(), largeRect.getY(), largeRect.getWidth(), largeRect.getHeight(), smallRect.getX(), smallRect.getY(), smallRect.getWidth(), smallRect.getHeight(), (2*largeRect.getWidth()+2*largeRect.getHeight()), (2*smallRect.getWidth()+2*smallRect.getHeight()), (largeRect.getWidth()*largeRect.getHeight()-smallRect.getWidth()*smallRect.getHeight()));
        
        // Moves the small rectangle 15 pixels to the left and 20pixels upward
        smallRect.setRect2D(smallRect.getX()-15, smallRect.getY()-20, smallRect.getWidth(), smallRect.getHeight());
        
        // Prints information about big and small rectangle, their perimeters, and their areas
        System.out.printf("%nAfter moving the small rectangle:%nBig rectangle: [x = %.2f; y = %.2f; w = %.2f; h = %.2f]%nSmall rectangle: [x = %.2f; y = %.2f; w = %.2f; h = %.2f]%nThe perimeter of the big rectangle is %.2f.%nThe perimeter of the small rectangle is %.2f.%nThe area of the big rectangle is %.2f.%nThe area of the small rectangle is %.2f.%n", largeRect.getX(), largeRect.getY(), largeRect.getWidth(), largeRect.getHeight(), smallRect.getX(), smallRect.getY(), smallRect.getWidth(), smallRect.getHeight(), (2*largeRect.getWidth()+2*largeRect.getHeight()), (2*smallRect.getWidth()+2*smallRect.getHeight()), (largeRect.getWidth()*largeRect.getHeight()), (smallRect.getWidth()*smallRect.getHeight()));
        
        // Doubles the width and halves the height of bigger rectangle while preserving location
        largeRect.setRect2D(largeRect.getX(), largeRect.getY(), largeRect.getWidth()*2, largeRect.getHeight()/2);
        
        // Prints information about big and small rectangle, their perimeters, their areas, and whether they contain (32.0, 32.0)
        System.out.printf("%nAfter resizing the big rectangle:%nBig rectangle: [x = %.2f; y = %.2f; w = %.2f; h = %.2f]%nSmall rectangle: [x = %.2f; y = %.2f; w = %.2f; h = %.2f]%nThe perimeter of the big rectangle is %.2f.%nThe perimeter of the small rectangle is %.2f.%nThe area of the big rectangle is %.2f.%nThe area of the small rectangle is %.2f.%nBig rectangle contains (32.0,32.0). %b%nSmall rectangle contains (32.0,32.0). %b%n", largeRect.getX(), largeRect.getY(), largeRect.getWidth(), largeRect.getHeight(), smallRect.getX(), smallRect.getY(), smallRect.getWidth(), smallRect.getHeight(), (2*largeRect.getWidth()+2*largeRect.getHeight()), (2*smallRect.getWidth()+2*smallRect.getHeight()), (largeRect.getWidth()*largeRect.getHeight()), (smallRect.getWidth()*smallRect.getHeight()), largeRect.contains(32.0, 32.0), smallRect.contains(32.0, 32.0));
    }
    
}
